module GossipsHelper
end
